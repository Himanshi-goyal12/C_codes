/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//print add two number using function
void sum(int ,int);
int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    sum(a,b);
}
void sum(int a,int b)
{
int c;
    printf("c=%d",a+b);

 }   
    


