/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float r;
    scanf("%f",&r);
    printf("diameter of circle=%f\n",2*r);
    printf("circumference of circle=%f\n",2*3.14*r);
    printf("area of circle=%f",3.14*3.14*r);

    return 0;
}
